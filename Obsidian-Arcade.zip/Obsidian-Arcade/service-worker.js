const CACHE_NAME =
  "obsidian-arcade-v1";

const FILES = [
  "./",
  "./index.html",
  "./manifest.json",

  "./games/snake.js",
  "./games/damas.js",
  "./games/rpg.js",
  "./games/desvia-carros.js"
];

self.addEventListener(
  "install",
  event => {

    event.waitUntil(

      caches
        .open(CACHE_NAME)
        .then(cache =>
          cache.addAll(FILES)
        )
        .catch(() => {})

    );

    self.skipWaiting();
  }
);

self.addEventListener(
  "activate",
  event => {

    event.waitUntil(

      caches
        .keys()
        .then(keys =>
          Promise.all(
            keys
              .filter(
                key =>
                  key !== CACHE_NAME
              )
              .map(
                key =>
                  caches.delete(key)
              )
          )
        )
    );

    self.clients.claim();
  }
);

self.addEventListener(
  "fetch",
  event => {

    event.respondWith(

      caches
        .match(event.request)
        .then(cached => {

          if (cached) {
            return cached;
          }

          return fetch(
            event.request
          ).catch(
            () => cached
          );
        })

    );
  }
);